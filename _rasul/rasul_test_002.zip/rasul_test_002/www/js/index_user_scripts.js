(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
         
        
        
        
        
        
        $(document).on("click", ".uib_w_77", function(evt)
        {
         activate_subpage("#catering_3"); 
        });
}
 $(document).ready(register_event_handlers);
})();
